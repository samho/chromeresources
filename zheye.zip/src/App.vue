<template>
  <!-- <div id="app"> -->
  <div class="container">
    <GlobalHeader :user="currentUser"></GlobalHeader>
    <RouterView></RouterView>
    <footer class="text-center py-4 text-secondary bg-light mt-6">
      <small>
        <ul class="list-inline mb-0">
          <li class="list-inline-item">2020 ZheYe 专栏</li>
          <li class="list-inline-item">课程</li>
          <li class="list-inline-item">文档</li>
          <li class="list-inline-item">联系</li>
          <li class="list-inline-item">更多</li>
        </ul>
      </small>
    </footer>
    <!-- <ValidateForm @form-submit="onFormSubmit">
      <div class="mb-6 col-4">
        <label class="form-label">Email address</label>
        <ValidateInput :rules="emailRules" v-model="emailValue"
          placeholder="Email" type="text">
        </ValidateInput>
      </div>
      <div class="mb-4 col-4">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <ValidateInput :rules="passwordRules" v-model="passwordValue"
          placeholder="Password" type="password">
        </ValidateInput>
      </div>
      <template #submitbtn >
        <button type="submit" class="btn btn-danger">Submit</button>
      </template>
    </ValidateForm> -->
    <!-- <Columnlist :itemlist="list"></Columnlist> -->
    <!-- <column-list :itemlist="list"></column-list> -->
  </div>
</template>

<script lang="ts">
import { computed, defineComponent } from 'vue'
import 'bootstrap/dist/css/bootstrap.min.css'
import { useStore } from 'vuex'
import GlobalHeader from './components/GlobalHeader.vue'


export default defineComponent({
  name: 'App',
  components: {
    GlobalHeader,
  },

  setup () {
    const store = useStore()
    const currentUser = computed(() => store.state.user)
    return {
      currentUser,
    }
  }
})
</script>

<style>
/* #app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
} */
</style>
