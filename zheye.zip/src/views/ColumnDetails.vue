<template>
  <div class="column-details-page w-75 mx-auto">
    <div class="column-info row mb-4 border-bottom pb-4 align-items-center">
        <div class="col-3 text-center">
            <img :src="column?.avator" :alt="column?.title" class="rounded-circle border border-light h-50 w-50 my-3">
        </div>
        <div class="col-9">
            <h4> {{ column?.title }}</h4>
            <p class="text-muted">{{ column?.description }}</p>
        </div>
    </div>
    <PostList :postlist="postlist"></PostList>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import { useRoute } from 'vue-router'
import { useStore } from 'vuex'
import PostList from '@/components/PostList.vue'
import { GlobalDataProps } from '@/store'

export default defineComponent({
  name: 'ColumnDetail',
  components: {
    PostList
  },
  setup() {
    const route = useRoute()
    const currentId = +route.params.id
    const store = useStore<GlobalDataProps>()
    const column = store.getters.getColumnList(currentId)
    const postlist = store.getters.getPostByColumnID(currentId)
    return {
      column,
      postlist
    }
  }
})

</script>