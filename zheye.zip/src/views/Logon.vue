<template>
    <ValidateForm @form-submit="onFormSubmit" class="mb-4">
      <div class="mb-6 col-4">
        <label class="form-label">Email address</label>
        <ValidateInput :rules="emailRules" v-model="emailValue"
          placeholder="Email" type="text">
        </ValidateInput>
      </div>
      <div class="mb-4 col-4">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <ValidateInput :rules="passwordRules" v-model="passwordValue"
          placeholder="Password" type="password">
        </ValidateInput>
      </div>
      <template #submitbtn >
        <button type="submit" class="btn btn-danger">Submit</button>
      </template>
    </ValidateForm>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import 'bootstrap/dist/css/bootstrap.min.css'
import ValidateForm from '../components/ValidateForm.vue'
import ValidateInput, { RulesProp } from '../components/ValidateInput.vue'
import { UserProps } from '@/components/dataModel'
import { useRouter } from 'vue-router'
import store from '@/store'

export default defineComponent({
  name: 'LOGON',
  components: {
    ValidateInput,
    ValidateForm
  },

  setup () {
    const router = useRouter()

    const emailValue = ref('')
    const emailRules: RulesProp = [
      { type: 'required', message: 'Email must be filled.' },
      { type: 'email', message: 'Email msut be valid.' }
    ]
    const passwordValue = ref('')
    const passwordRules: RulesProp = [
      { type: 'required', message: 'Password must be filled.' }
    ]
    const onFormSubmit = (result: boolean) => {
      console.log(result)
      if (result) {
        const logonUser: UserProps = {
          id: 1,
          name: 'Sam Ho',
          columnId: 1,
          isLogon: true
          }
        store.commit('login', logonUser)
        console.log('Logon islogon:', store.state.user.isLogon)
        router.push('/')
        }
      }
    return {
      emailRules,
      emailValue,
      passwordRules,
      passwordValue,
      onFormSubmit
    }
  }
})
</script>