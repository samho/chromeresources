<template>
  <ColumnList :itemlist="list"></ColumnList>
</template>

<script lang="ts">
import { computed, defineComponent } from 'vue';
import { useStore } from 'vuex';
import { GlobalDataProps } from '@/store';
import ColumnList from '../components/ColumnList.vue';

export default defineComponent({
  name: 'HOME',
  components: {
    ColumnList
  },
  setup () {
    const store = useStore<GlobalDataProps>()
    console.log('Home islogon:', store.state.user.isLogon)
    const columnItemList = computed(() => store.state.columns)
    return {
      list: columnItemList,
    }
  }
}) 
</script>