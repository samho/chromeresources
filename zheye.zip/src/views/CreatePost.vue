<template>
    <div class="creaet-post-page">
        <h4>创建文章</h4>        
        <ValidateForm @form-submit="onFormSubmit">
            <div class="mb-3">
                <label class="form-label">文章标题: </label>
                <ValidateInput :rules="titleRules" v-model="titleValue"
                    placeholder="请输入文章标题" type="text">
                </ValidateInput>
            </div>
            <div class="mb-3">
                <label class="form-label">文章内容: </label>
                <ValidateInput :rules="contentRules" v-model="contentValue"
                  placeholder="文章内容" type="text" tag="textarea" rows="10">
                </ValidateInput>
            </div>
            <template #submitbtn >
                <button type="submit" class="btn btn-primary">Submit</button>
            </template>
        </ValidateForm>
    </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import 'bootstrap/dist/css/bootstrap.min.css'
import ValidateForm from '../components/ValidateForm.vue'
import ValidateInput, { RulesProp } from '../components/ValidateInput.vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { GlobalDataProps } from '@/store'
import { PostProps } from '@/components/dataModel'

export default defineComponent({
  name: 'POSTCREATE',
  components: {
    ValidateInput,
    ValidateForm
  },

  setup () {
    const router = useRouter()
    const store = useStore<GlobalDataProps>()

    const titleValue = ref('')
    const titleRules: RulesProp = [
      { type: 'required', message: 'Title is required.' }
    ]
    const contentValue = ref('')
    const contentRules: RulesProp = []
    const onFormSubmit = (result: boolean) => {
      console.log(result)
      if (result) {
        const { columnId } = store.state.user
        if (columnId) {
          const newPost: PostProps = {
            id: new Date().getTime(),
            title: titleValue.value,
            content: contentValue.value,
            columnId,
            createdAt: new Date().toLocaleString()
            }
          store.commit('createPost', newPost)  
          router.push({name: 'column', params: {id: columnId}})
        }
        // router.push({name: 'column', params: {id: logonUser.id}})
        }
      }
    return {
      titleRules,
      titleValue,
      contentRules,
      contentValue,
      onFormSubmit
    }
  }
})
</script>