import { createRouter, createWebHistory } from 'vue-router'
import Home from './views/Home.vue'
import Logon from './views/Logon.vue'
import ColumnDetail from './views/ColumnDetails.vue'
import CreatePost from './views/CreatePost.vue'
import store from './store'

const routerHistory = createWebHistory()
const router = createRouter({
  history: routerHistory,
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/column/:id?',
      name: 'column',
      component: ColumnDetail,
      meta: {
        requiredLogin: true
      }
    },
    {
      path: '/create',
      name: 'create',
      component: CreatePost,
      meta: {
        requiredLogin: true
      }
    },

    {
      path: '/login',
      name: 'login',
      component: Logon
    }
  ]
})

router.beforeEach((to, from, next) => {
  // next(false) //same as without it.
  console.log("login meta: ", to.meta.redirectAlreadyLogin, store.state.user.isLogon, to.meta.requiredLogin)
  if (to.meta.requiredLogin && !store.state.user.isLogon) {
    next({name: 'login'})
  } else if (to.name === 'login' && store.state.user.isLogon) {
    next({name: 'home'})
  }
  else {
    next()
  }
})

export default router