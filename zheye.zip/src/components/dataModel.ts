export interface UserProps {
  isLogon: boolean,
  name?: string,
  id?: number,
  columnId?: number
}

export interface ColumnProps {
    id: number;
    title: string;
    avator ?: string;
    description: string;
}

export const testData: ColumnProps[] = [
    {
      id: 1,
      title: 'Test 1',
      description: 'This is the test 1 desc.',
      avator: 'http://gips3.baidu.com/it/u=3886271102,3123389489&fm=3028&app=3028&f=JPEG&fmt=auto?w=1280&h=960'
    },
    {
      id: 2,
      title: 'Test 2',
      description: 'This is the test 2 desc.',
      avator: 'http://gips0.baidu.com/it/u=3944689179,983354166&fm=3028&app=3028&f=JPEG&fmt=auto?w=1024&h=1024'
    },
    {
      id: 3,
      title: 'Test 3',
      description: 'This is the test 3 desc.',
      avator: 'http://gips0.baidu.com/it/u=3375143540,3287761352&fm=3028&app=3028&f=JPEG&fmt=auto?w=960&h=1280'
    },
    {
      id: 4,
      title: 'Test 4',
      description: 'This is the test 4 desc.',
      avator: 'http://gips0.baidu.com/it/u=3557606594,2640240494&fm=3028&app=3028&f=JPEG&fmt=auto?w=2048&h=2048'
    },
    {
      id: 5,
      title: 'Test 5',
      description: 'This is the test 5 desc.'
    }
  ]

export interface PostProps {
  id: number;
  title: string;
  content: string;
  image?: string;
  createdAt: string;
  columnId: number;
}

export const testPost: PostProps[] = [
  {
    id: 1,
    title: 'Column 1  Post 1',
    content: 'This is Post 1.',
    image: 'https://pic.rmb.bdstatic.com/bjh/d5e7b01ffc5a4190d56f6e63b6815d0c5687.jpeg?x-bce-process=image/watermark,bucket_baidu-rmb-video-cover-1,image_YmpoL25ld3MvNjUzZjZkMjRlMDJiNjdjZWU1NzEzODg0MDNhYTQ0YzQucG5n,type_RlpMYW5UaW5nSGVpU01HQg==,w_23,text_QOaiheS9oOS4jeihjGRl5aS05YOP,size_23,x_18,y_18,interval_2,color_FFFFFF,effect_softoutline,shc_000000,blr_2,align_1',
    createdAt: '2024-05-26',
    columnId: 1
  },
  {
    id: 2,
    title: 'Column 1  Post 2',
    content: 'This is Post 2.',
    image: 'https://img2.baidu.com/it/u=2825154656,1815469973&fm=253&fmt=auto&app=120&f=JPEG?w=669&h=494',
    createdAt: '2024-05-26',
    columnId: 1
  },
  {
    id: 3,
    title: 'Column 1  Post 3',
    content: 'This is Post 3.',
    image: 'https://img2.woyaogexing.com/2019/08/27/1a5816bf758a482d9eb12477d4895775%21600x600.jpeg',
    createdAt: '2024-05-26',
    columnId: 1
  },
  {
    id: 4,
    title: 'Column 2  Post 1',
    content: 'This is Post 1.',
    image: 'https://tupian.qqw21.com/article/UploadPic/2022-5/202252418392227435.jpeg',
    createdAt: '2024-05-26',
    columnId: 2
  },
  {
    id: 5,
    title: 'Column 3  Post 1',
    content: 'This is Post 1.',
    image: 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fsafe-img.xhscdn.com%2Fbw1%2Fdf18966b-4bb9-47cc-b8ce-69f11694b80f%3FimageView2%2F2%2Fw%2F1080%2Fformat%2Fjpg&refer=http%3A%2F%2Fsafe-img.xhscdn.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1719327255&t=7d119ea275392ea321e1580aee9e95d2',
    createdAt: '2024-05-26',
    columnId: 3
  }
]