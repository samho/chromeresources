<template>
    <form class="validate-form-container">
        <slot name="default"></slot>
        <div class="submit-area" @click.prevent="submitform">
            <slot name="submitbtn">
                <button type="submit" class="btn btn-primary">Submit</button>
            </slot>
        </div>
    </form>
</template>

<script lang="ts">
import { defineComponent, onUnmounted } from 'vue'
import mitt from 'mitt'

type Events = {
  'form-item-created': string,
  'form-item-validation': () => boolean
}

type ValidateFunc = () => boolean

export const emiiter = mitt<Events>()

export default defineComponent({
  emits: ['form-submit'],
  setup (props, contex) {
    let funcArr: ValidateFunc[] = []
    const submitform = () => {
      // every 方法，在碰到false后，直接返回，不会继续执行后续内容
    //   const result = funcArr.every(func => func())
      // map方法，返回一个数组结果, 再通过every方法，将所有结果返回
      const result = funcArr.map(func => func()).every(result => result)
      contex.emit('form-submit', result)
    }
    const callback = (func: ValidateFunc) => {
      funcArr.push(func)
    }
    emiiter.on('form-item-validation', callback)
    onUnmounted(() => {
      emiiter.off('form-item-validation', callback)
      funcArr = []
    })

    return {
      submitform
    }
  }

})
</script>
