<template>
  <div class='row'>
    <div class='col-4 mb-4' v-for="column in columnlist" :key="column.id">
      <div class="card h-100 shadow">
        <div class="card-body text-center">
          <img :src="column.avator" :alt="column.title" class="card-img-top rounded-circle border border-light h-50 w-50 my-3">
          <h5 class="card-title">{{ column.title }}</h5>
          <p class="card-text">{{ column.description }}</p>
          <!-- <RouterLink :to="{name: 'column', params:{id: column.id}}" class="btn btn-outline-primary">进入专栏</RouterLink> -->
          <RouterLink :to="`/column/${ column.id }`" class="btn btn-outline-primary">进入专栏</RouterLink>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">

import { computed, defineComponent, PropType } from 'vue'
import { ColumnProps } from './dataModel'


export default defineComponent({
  name: 'ColumnList',
  props: {
    itemlist: {
      type: Array as PropType<ColumnProps[]>,
      required: true
    }
  },
  setup (props) {
    const columnlist = computed(() => {
      return props.itemlist.map(column => {
        if (!column.avator) {
          column.avator = require('@/assets/no-image.jpg')
        }
        return column
      })
    })
    return { columnlist }
  }
})

</script>
