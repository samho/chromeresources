<template>
  <nav class="navbar navbar-dark bg-primary justify-content-between mb-4 px-4" data-bs-theme="dark">
  <!-- Navbar content -->
    <RouterLink class="navbar-brand" :to="{name: 'home'}" >者也专栏</RouterLink>
    <ul v-if="!user?.isLogon" class="list-inline mb-0">
      <li class="list-inline-item"><RouterLink :to="{name: 'login'}" class="btn btn-outline-light my-2">Login</RouterLink></li>
      <li class="list-inline-item"><a href="#" class="btn btn-outline-light my-2">Sign Up</a></li>
    </ul>
    <ul v-else class="list-inline mb-0">
      <li class="list-inline-item">
        <!-- <a href="#" class="btn btn-outline-light my-2">Hello, {{ user.name }}</a> -->
        <LogonDropdown :title='`Hello, ${user.name}`'>
          <DropdownItem><RouterLink class="dropdown-item" :to="{name: 'create'}">New Post</RouterLink></DropdownItem>
          <DropdownItem><a class="dropdown-item" href="#">Edit User</a></DropdownItem>
          <DropdownItem><RouterLink class="dropdown-item" :to="{name: 'login'}">login</RouterLink></DropdownItem>
        </LogonDropdown>
    </li>
    </ul>
  </nav>
</template>

<script lang="ts">
import { PropType, defineComponent } from 'vue'
import LogonDropdown from './Dropdown.vue'
import DropdownItem from './DropdownItem.vue'
import { UserProps } from './dataModel'

// export interface UserProps {
//   isLogon: boolean;
//   name ?: string;
//   id: number;
// }

export default defineComponent({
  name: 'GlobalHeader',
  components: {
    LogonDropdown,
    DropdownItem
  },
  props: {
    user: {
      type: Object as PropType<UserProps>,
      require: true
    }
  }
})
</script>

<style>
</style>
