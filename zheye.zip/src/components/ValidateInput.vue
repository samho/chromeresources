<template>
  <div class="validate-input-contaner pb-3">
    <input
    v-if="tag !== 'textarea'"
    class="form-control"
    :class="{'is-invalid': inputRef.error}"
    :value="inputRef.val"
    @blur="validateInput"
    @input="updateValue"
    v-bind="$attrs
    ">
    <textarea
    v-else
    class="form-control"
    :class="{'is-invalid': inputRef.error}"
    :value="inputRef.val"
    @blur="validateInput"
    @input="updateValue"
    v-bind="$attrs
    "></textarea>
    <div v-if=inputRef.error class="invalid-feedback">{{ inputRef.message }}</div>
  </div>
    <!-- v-model="inputRef.val" -->
</template>

<script lang='ts'>
import { defineComponent, reactive, PropType, onMounted } from 'vue'
import { emiiter } from './ValidateForm.vue'

const emailfmt = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/

export interface RuleProp {
  type: 'required' | 'email';
  message: string;
}

export type RulesProp = RuleProp[]

export type TagType = 'input' | 'textarea'

export default defineComponent({
  name: 'ValidateInput',
  inheritAttrs: false,
  props: {
    rules: Array as PropType<RulesProp>,
    modelValue: String,
    tag: {
      type: String as PropType<TagType>,
      default: 'input'
    }
  },
  setup (props, contex) {
    console.log('Start to vaildate.')
    console.log(contex.attrs)
    const inputRef = reactive({
      val: props.modelValue || '',
      error: false,
      message: ''
    })
    const updateValue = (e: Event) => {
      const targetvalue = (e.target as HTMLInputElement).value
      inputRef.val = targetvalue
      contex.emit('update:modelValue', targetvalue)
    }
    const validateInput = () => {
      if (props.rules) {
        const allPassed = props.rules.every(rule => {
          let passed = true
          inputRef.message = rule.message
          switch (rule.type) {
            case 'required':
              passed = (inputRef.val.trim() !== '')
              break
            case 'email':
              passed = (emailfmt.test(inputRef.val))
              break
            default:
              break
          }
          return passed
        })
        inputRef.error = !allPassed
        return allPassed
      } else {
        return true
      }
    }
    onMounted(() => {
      emiiter.emit('form-item-validation', validateInput)
    })
    return {
      inputRef,
      validateInput,
      updateValue
    }
  }
})

</script>
