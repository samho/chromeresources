<template>
  <div class="post-list">
    <article v-for="post in postlist" :key="post.id" class="card mb-3 shadow">
      <div class="card-body">
        <h4>{{ post.title }}</h4>
        <div class="row my-3 algin-item-center">
          <div v-if="post.image" class="col-3">
            <img :src="post.image" class="rounded-lg border border-light h-50 w-50 my-3">
          </div>
          <p :class="{'col-9': post.image}">{{ post.content }}</p>
        </div>
        <span class="text-muted">{{ post.createdAt }}</span>
      </div>
    </article>
  </div>
</template>

<script lang="ts">
import { defineComponent, PropType } from 'vue';
import { PostProps } from './dataModel';

export default defineComponent({
    name: 'PostList',
    props: {
        postlist: {
          type: Array as PropType<PostProps[]>,
          required: true
        }
    }
})

</script>