<template>
<div class="dropdown" ref="dropdownRef">
    <a href="#" @click="LogonTogoleOpen" class="btn btn-outline-light my-2 dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">{{ title }}</a>
    <ul v-if="isOpenLogon" class="dropdown-menu" :style="{display: 'block'}" >
    <slot></slot>
    <!-- <li><a class="dropdown-item" href="#">New Post</a></li> -->
    <!-- <li><a class="dropdown-item" href="#">Edit User</a></li> -->
    </ul>
</div>
</template>

<script lang="ts">
import { defineComponent, ref, watch } from 'vue'
import useClickOutside from '../hooks/useClickOutside'

export default defineComponent({
  name: 'LogonDropdown',
  props: {
    title: {
      type: String,
      required: true
    }
  },
  setup () {
    const isOpenLogon = ref(false)
    const dropdownRef = ref<null | HTMLElement>(null)
    const LogonTogoleOpen = () => {
      isOpenLogon.value = !isOpenLogon.value
    }
    const isClickOutside = useClickOutside(dropdownRef)

    watch(isClickOutside, () => {
      if (isClickOutside && isOpenLogon.value) {
        isOpenLogon.value = false
      }
    })
    return {
      isOpenLogon,
      LogonTogoleOpen,
      dropdownRef
    }
  }
})
</script>
