<template>
    <form class="validate-form-container">
        <slot name="default"></slot>
        <div class="submit-area" @click.prevent="submitform">
            <slot name="submitbtn">
                <button type="submit" class="btn btn-primary">Submit</button>
            </slot>
        </div>
    </form>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  emits: ['form-submit'],
  setup (props, contex) {
    const submitform = () => {
      contex.emit('form-submit', true)
    }
    return {
      submitform
    }
  }

})
</script>
