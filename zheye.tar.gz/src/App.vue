<template>
  <!-- <div id="app"> -->
  <div class="container">
    <GlobalHeader :user="currentUser"></GlobalHeader>
    <ValidateForm @form-submit="onFormSubmit">
      <div class="mb-6 col-4">
        <label class="form-label">Email address</label>
        <ValidateInput :rules="emailRules" v-model="emailValue"
          placeholder="Email" type="text" class="hello">
        </ValidateInput>
      </div>
      <div class="mb-4 col-4">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword1">
      </div>
      <template #submitbtn >
        <button type="submit" class="btn btn-danger">Submit</button>
      </template>
    </ValidateForm>
    <!-- <Columnlist :itemlist="list"></Columnlist> -->
    <!-- <column-list :itemlist="list"></column-list> -->
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
import 'bootstrap/dist/css/bootstrap.min.css'
import Columnlist, { ColumnProps } from './components/ColumnList.vue'
import ValidateForm from './components/ValidateForm.vue'
import GlobalHeader, { UserProps } from './components/GlobalHeader.vue'
import ValidateInput, { RulesProp } from './components/ValidateInput.vue'

const currentUser: UserProps = {
  isLogon: true,
  name: 'Sam Ho',
  id: 1
}

const testData: ColumnProps[] = [
  {
    id: 1,
    title: 'Test 1',
    description: 'This is the test 1 desc.',
    avator: 'http://gips3.baidu.com/it/u=3886271102,3123389489&fm=3028&app=3028&f=JPEG&fmt=auto?w=1280&h=960'
  },
  {
    id: 2,
    title: 'Test 2',
    description: 'This is the test 2 desc.',
    avator: 'http://gips0.baidu.com/it/u=3944689179,983354166&fm=3028&app=3028&f=JPEG&fmt=auto?w=1024&h=1024'
  },
  {
    id: 3,
    title: 'Test 3',
    description: 'This is the test 3 desc.',
    avator: 'http://gips0.baidu.com/it/u=3375143540,3287761352&fm=3028&app=3028&f=JPEG&fmt=auto?w=960&h=1280'
  },
  {
    id: 4,
    title: 'Test 4',
    description: 'This is the test 4 desc.',
    avator: 'http://gips0.baidu.com/it/u=3557606594,2640240494&fm=3028&app=3028&f=JPEG&fmt=auto?w=2048&h=2048'
  },
  {
    id: 5,
    title: 'Test 5',
    description: 'This is the test 5 desc.'
  }
]

export default defineComponent({
  name: 'App',
  components: {
    // Columnlist,
    GlobalHeader,
    ValidateInput,
    ValidateForm
  },

  setup () {
    const emailValue = ref('')
    const emailRules: RulesProp = [
      { type: 'required', message: 'Email must be filled.' },
      { type: 'email', message: 'Email msut be valid.' }
    ]
    // const emailRef = reactive({
    //   val: '',
    //   error: false,
    //   message: ''
    // })
    // const validateEmail = () => {
    //   if (emailRef.val.trim() === '') {
    //     emailRef.error = true
    //     emailRef.message = 'Email cannot be empty.'
    //   } else if (!emailfmt.test(emailRef.val)) {
    //     emailRef.error = true
    //     emailRef.message = 'Email format invalid.'
    //   } else {
    //     emailRef.error = false
    //     emailRef.message = ''
    //   }
    // }
    const onFormSubmit = (result: boolean) => {
      console.log('123', result)
    }
    return {
      list: testData,
      currentUser,
      // validateEmail,
      // emailRef,
      emailRules,
      emailValue,
      onFormSubmit
    }
  }
})
</script>

<style>
/* #app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
} */
</style>
